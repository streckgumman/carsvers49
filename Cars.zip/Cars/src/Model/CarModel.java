package Model;

import Observer.ViewObserver;

import java.util.ArrayList;
import java.util.List;


public class CarModel{



}
