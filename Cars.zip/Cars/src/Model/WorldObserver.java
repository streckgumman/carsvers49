package Model;

public interface WorldObserver {
    void actOnWorldChange();
}
