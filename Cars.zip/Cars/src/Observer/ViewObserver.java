package Observer;

public interface ViewObserver {

    void actOnModelChange();

}
